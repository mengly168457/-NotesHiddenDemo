import SwiftUI

@main
struct NotesHiddenDemoApp: App {
    var body: some Scene {
        WindowGroup {
            NotesView()
        }
    }
}

struct NotesView: View {
    @State private var titleTaps = 0
    @State private var showMainUI = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Welcome to Notes")
                        .font(.title2.weight(.semibold))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            titleTaps += 1
                            if titleTaps == 5 {
                                titleTaps = 0
                                showMainUI = true
                            }
                        }
                }

                Section("Notes") {
                    Label("My Notes", systemImage: "note.text")
                    Label("Recently Deleted", systemImage: "trash")
                }
            }
            .navigationTitle("Notes")
            .sheet(isPresented: $showMainUI) {
                DemoMainView()
            }
        }
    }
}

struct DemoMainView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                Image(systemName: "rectangle.3.group")
                    .font(.system(size: 58))
                Text("Demo Main UI")
                    .font(.largeTitle.bold())
                Text("The hidden-screen demonstration is working.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)

                Button("Close") {
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .navigationTitle("Main UI")
        }
    }
}
