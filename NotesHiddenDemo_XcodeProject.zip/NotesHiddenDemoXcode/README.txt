NotesHiddenDemo
================

Standalone iOS demo.

Behavior:
- Opens as a Notes-style screen.
- Tap "Welcome to Notes" five times.
- Demo Main UI opens.
- No ESP, game cheat, or modification of another app is included.

For Codemagic:
1. Put this folder in a Git repository (the .xcodeproj and NotesHiddenDemo folder must stay together).
2. Connect the repository to Codemagic.
3. Select the NotesHiddenDemo.xcodeproj.
4. Configure iOS signing with your own Apple Developer credentials.
5. Build and export the IPA.
